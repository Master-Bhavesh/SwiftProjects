//
//  Wage.swift
//  WindowShopper
//
//  Created by Bhavesh Rajaram Patil on 02/07/20.
//  Copyright © 2020 Bhavesh Rajaram Patil. All rights reserved.
//

import Foundation

class Wage
{
    class func getHours(forWage wage:Double,andPrice price:Double) -> Int
    {
        return Int(ceil(price / wage))
    }
}
