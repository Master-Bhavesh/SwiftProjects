//
//  ViewController.swift
//  WindowShopper
//
//  Created by Bhavesh Rajaram Patil on 02/07/20.
//  Copyright © 2020 Bhavesh Rajaram Patil. All rights reserved.
//

import UIKit

class MainViewController: UIViewController
{
    
    @IBOutlet weak var wageText: currencyTextField!
    @IBOutlet weak var priceText: currencyTextField!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var hoursLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let calcButton = UIButton(frame: CGRect(x: 0,y: 0,width: view.frame.size.width,height: 60))
        calcButton.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        calcButton.setTitle("Calculate", for: .normal)
        calcButton.setTitleColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1),for: .normal)
        calcButton.addTarget(self, action:#selector(MainViewController.calculate),for: .touchUpInside)
        
        wageText.inputAccessoryView = calcButton
        priceText.inputAccessoryView = calcButton
        
        resultLabel.isHidden = true
        hoursLabel.isHidden = true
    }
    @objc func calculate()
    {
        if let wageText = wageText.text, let priceText = priceText.text
        {
            if let wage = Double(wageText), let price = Double(priceText)
            {
                view.endEditing(true)
                resultLabel.isHidden = false
                hoursLabel.isHidden = false
                resultLabel.text = "\(Wage.getHours(forWage: wage,andPrice: price))"
            }
        }
    }
    
    @IBAction func clearCalculatorPressed(_ sender: Any)
    {
        resultLabel.isHidden = true
        hoursLabel.isHidden = true
        wageText.text = ""
        priceText.text = ""
    }
}

